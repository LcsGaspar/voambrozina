from flask import Flask, render_template, request, redirect
import mysql.connector

app = Flask(__name__)


# Configuração do banco de dados
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",  # Se a senha estiver em branco, deixe assim
    database="curso_inscricao",
    port=3306  # Use a porta 3306, que é a padrão do MySQL no XAMPP
)


# Página do formulário de inscrição
@app.route('/')
def formulario():
    return render_template('formulario.html')

# Rota para processar o formulário
@app.route('/inscrever', methods=['POST'])
def inscrever():
    nome = request.form['nome']
    email = request.form['email']
    curso = request.form['curso']

    cursor = db.cursor()
    cursor.execute("INSERT INTO inscritos (nome, email, curso) VALUES (%s, %s, %s)", (nome, email, curso))
    db.commit()
    cursor.close()

    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)



